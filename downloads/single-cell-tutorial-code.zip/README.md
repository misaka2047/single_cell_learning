# 单细胞研究范式入门：人类胰岛图谱与 2 型糖尿病再分析

这是一个面向刚入学的医学研究生的**完整、可复现**单细胞转录组教程。它不只是一份
流程清单：两个公开数据集被真实下载、处理、聚类、注释并做差异表达，代码和结果都在
本目录中。

> **交互式逐步网站**：[site/index.html](site/index.html) —— 12 步 + 附录，含进度、
> 搜索、术语悬停注释、预期结果、检查点和排错表；比本 README 更适合边做边学。

- **数据集 A：GSE84133**（Baron et al., *Cell Systems* 2016）——4 名供者、8,569 个
  人胰岛细胞，用于无监督图谱、聚类和注释。
- **数据集 B：GSE81608**（Xin et al., *Cell Metabolism* 2016）——18 名供者
  （12 非糖尿病、6 型 2 糖尿病）、1,600 个 α/β/δ/PP 细胞，用于供者水平 pseudobulk
  差异表达。

> 重要结论：在 GSE81608 中，**细胞水平朴素检验**会给出 1,217 个“显著”基因，但把
> 供者作为推断单位后（pseudobulk，16 名供者）**没有基因通过 FDR<0.05**；而
> β vs α 的阳性对照有 3,086 个基因显著。这说明流程本身有检验效能，T2D 的全局
> 差异在本数据/本模型下不可检出，也说明“把细胞当重复”会严重夸大显著性。

## 快速开始

```powershell
python -m pip install -r requirements.txt

# Windows 上 numba/llvmlite 的 SVML 兼容性 workaround；其他平台可省略
$env:NUMBA_DISABLE_INTEL_SVML = "1"

# 数据下载见 data/README.md（本仓库不附带原始数据）
python code/00_prepare_data.py
python code/01_baron_cluster.py
python code/02_baron_annotate.py
python code/03_gse81608_cluster.py
python code/04_gse81608_de.py
python code/05_report_figures.py
```

完整讲解见 **[REPORT.md](REPORT.md)**，网页版为 **[REPORT.html](REPORT.html)**。

## 目录

```
.
├─ REPORT.md / REPORT.html      # 主教程（中文）
├─ site/                        # 交互式逐步网站（12 步 + 附录）
├─ requirements.txt
├─ code/
│  ├─ download_ranges.py        # 多线程 HTTP Range 下载（gzip 拼接）
│  ├─ 00_prepare_data.py        # CSV/RPKM -> AnnData
│  ├─ 01_baron_cluster.py       # 数据集 A：QC、HVG、PCA、UMAP、Leiden
│  ├─ 02_baron_annotate.py      # 数据集 A：marker 注释、ARI、组成
│  ├─ 03_gse81608_cluster.py    # 数据集 B：QC、log2、聚类
│  ├─ 04_gse81608_de.py         # 数据集 B：注释、pseudobulk DE、阳性/阴性对照
│  ├─ 05_report_figures.py      # 汇总指标与对照图
│  └─ 06_session_info.py        # 版本信息
├─ data/                        # 原始数据（需自行下载）与 processed/*.h5ad
├─ figures/                     # 所有图（PNG）
└─ results/                     # 所有表（CSV）、日志、session info
```

## 主要结果

| 指标 | GSE84133 | GSE81608 |
|---|---|---|
| 原始细胞 × 基因 | 8,569 × 20,125 | 1,600 × 39,851 |
| QC 后细胞 × 基因 | 8,531 × 16,353 | 1,600 × 39,851 |
| 供者（对照/T2D） | 4（3/1） | 18（12/6） |
| 聚类数 / 注释类型 | 19 / 11 | 8 / 4 |
| 与作者标签 ARI | 0.968 | 0.856 |
| 主要用途 | 图谱与注释 | T2D vs 对照 DE |

关键图：

- `figures/baron_umap_overview.png`
- `figures/baron_umap_annotated.png`
- `figures/gse81608_umap_overview.png`
- `figures/de_method_comparison.png`
- `figures/gse81608_pvalue_diagnostics.png`

## 数据与伦理

所有数据均为公共、去标识化的 GEO 数据。请遵守 GEO/NCBI 的使用条款，并在论文中
引用原始数据和论文。不要把“公共数据再分析”写成“我们收集的队列”。

## 引用

1. Baron M, et al. A Single-Cell Transcriptomic Map of the Human and Mouse Pancreas
   Reveals Inter- and Intra-cell Population Structure. *Cell Syst*. 2016;3(4):346-360.e4.
   doi:10.1016/j.cels.2016.08.011
2. Xin Y, et al. RNA Sequencing of Single Human Islet Cells Reveals Type 2 Diabetes
   Genes. *Cell Metab*. 2016;24(4):608-615. doi:10.1016/j.cmet.2016.08.018
3. Squair JW, et al. Confronting false discoveries in single-cell differential
   expression. *Nat Commun*. 2021;12:5692. doi:10.1038/s41467-021-25960-2
4. Murphy AE, Skene NG. A balanced measure shows superior performance of pseudobulk
   methods in single-cell RNA-sequencing analysis. *Nat Commun*. 2022;13:7851.
   doi:10.1038/s41467-022-35519-4
